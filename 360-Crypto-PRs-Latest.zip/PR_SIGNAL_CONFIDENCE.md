
# PR: Signal Confidence Scoring

## Objective
AI-based confidence scoring and suppression:
- Probabilistic confidence per signal
- Suppress low-confidence and correlated signals

## Steps
1. Update `confidence.py` for per-signal scoring
2. Integrate cluster suppression for correlated signals
3. Adaptive thresholds per regime and pair volatility
4. Include confidence metadata in signals
