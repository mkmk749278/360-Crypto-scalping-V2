
# PR: Dynamic Pair Selection

## Objective
Dynamic universe selection for Binance Spot + Futures:
- Top N pairs by volume, liquidity, volatility
- Include sudden volume spike pairs

## Steps
1. `pair_manager.py` to rank and update watchlist
2. AI inference runs on all pairs but publishes only top-ranked
3. Suppress low-confidence / low-volume pair signals
