
# PR: Advanced Backtesting Framework

## Objective
Enhance backtesting to simulate real-world conditions:
- Include suppression rules, confidence decay, regime scenarios
- Track per-pair ROI and win-rate

## Steps
1. Update `backtester.py` to integrate AI and suppression
2. Generate analytics reports
3. Monte Carlo and regime-based stress tests
