
# PR: AI Engine Refactor

## Objective
Refactor `ai_engine.py` into modular predictive AI engine:
- Signal prediction
- Confidence scoring
- Feedback loop integration

## Steps
1. Split `ai_engine.py` into:
   - `ai_engine/predictor.py`
   - `ai_engine/confidence.py`
   - `ai_engine/feedback_loop.py`
2. Async real-time inference pipeline
3. Multi-factor feature support (price, volume, order book, correlation)
4. Confidence scoring with dynamic thresholds
5. Integrate with `signal_router.py` for publishing high-confidence signals
