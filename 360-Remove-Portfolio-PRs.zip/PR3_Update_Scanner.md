
# PR3: Update Scanner for Active Trades Only

## Objective
Simplify scanner to feed only active trade signals.

## Steps
1. Remove portfolio-related suppression, filters, or analytics.
2. Ensure scanner loops feed signals directly to active trade channel.
3. Adjust telemetry to remove portfolio metrics.
