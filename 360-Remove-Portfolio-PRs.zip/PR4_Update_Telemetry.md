
# PR4: Update Telemetry and Logging

## Objective
Clean up telemetry to track only active trade signals.

## Steps
1. Remove portfolio-specific metrics from logs/telemetry collector.
2. Ensure active trade logs remain intact.
3. Optional: log top 50 active futures only.
