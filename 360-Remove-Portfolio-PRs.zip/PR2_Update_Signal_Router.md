
# PR2: Update Signal Router for Active Trades Only

## Objective
Ensure signal routing only handles active trades.

## Steps
1. Remove logic that groups signals per portfolio.
2. Remove posting of free/condensed portfolio signals.
3. Update dependencies so active trade signals are independent.
