
# 360 Main Engine - Portfolio Removal Instructions

## Overview
After this PR, the engine will focus exclusively on **active trades**, futures markets only. Portfolio channels and aggregation are removed for performance and simplicity.

## Steps to Apply
1. Apply PR1 → remove portfolio modules.
2. Apply PR2 → update signal router for active trades.
3. Apply PR3 → adjust scanner for active trades only.
4. Apply PR4 → clean telemetry and logging.
5. Test the engine for active trade signals:
   - Top 50 dynamic futures
   - Pre-entry scalps (if implemented)
   - AI confidence scoring (if used)
6. Ensure logs and metrics only track active trades.
7. Deploy updated engine on VPS.
