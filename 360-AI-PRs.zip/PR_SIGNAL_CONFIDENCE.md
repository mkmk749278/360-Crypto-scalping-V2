
# PR: Signal Confidence Scoring

## Objective
Implement AI-based confidence scoring and suppression rules:
- Compute probabilistic confidence per signal
- Suppress low-confidence and correlated signals

## Implementation Steps
1. Update `confidence.py` to support per-signal confidence
2. Integrate cluster suppression for correlated signals
3. Implement adaptive thresholds based on market regime and pair volatility
4. Provide metadata for each signal (confidence score, suppressed status)

## Notes
- Ensure signals returned to `signal_router.py` include confidence field
- Consider historical success rates in scoring
