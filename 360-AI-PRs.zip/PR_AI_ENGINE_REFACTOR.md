
# PR: AI Engine Refactor

## Objective
Refactor `ai_engine.py` into a modular predictive AI engine with clear interfaces for:
- Signal prediction
- Confidence scoring
- Feedback loop integration

## Implementation Steps
1. Split AI engine into modules:
   - `ai_engine/predictor.py`
   - `ai_engine/confidence.py`
   - `ai_engine/feedback_loop.py`
2. Implement async real-time inference pipeline.
3. Add multi-factor feature support (price, volume, order book, correlation).
4. Add per-pair confidence scoring with dynamic thresholds.
5. Integrate with `signal_router.py` for publishing high-confidence signals only.

## Notes
- Ensure backward compatibility with current signal router.
- Unit tests for each AI module.
