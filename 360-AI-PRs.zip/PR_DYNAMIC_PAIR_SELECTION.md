
# PR: Dynamic Pair Selection

## Objective
Implement dynamic universe selection for Binance Spot + Futures pairs:
- Focus on top N pairs by volume, liquidity, volatility
- Include sudden volume spike pairs dynamically

## Implementation Steps
1. Create `pair_manager.py` module:
   - Methods to rank pairs by volume, volatility, liquidity
   - Dynamically update watchlist every X minutes
2. Integrate with AI engine to run inference on all pairs but only push top-ranked signals
3. Suppress low-confidence / low-volume pair signals

## Notes
- Store historical pair metrics for analytics
- Ensure async processing to maintain low latency
